#include "version.h"

static const char libhugetlbfs_version[] = "VERSION: "VERSION;
