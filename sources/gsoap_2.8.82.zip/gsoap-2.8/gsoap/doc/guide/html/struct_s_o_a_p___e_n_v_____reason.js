var struct_s_o_a_p___e_n_v_____reason =
[
    [ "SOAP_ENV__Text", "struct_s_o_a_p___e_n_v_____reason.html#a4e7a5850ce6987bf6d15bf9fea780ecd", null ]
];