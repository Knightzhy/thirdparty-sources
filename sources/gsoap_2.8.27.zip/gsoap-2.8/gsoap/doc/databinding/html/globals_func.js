var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "g", "globals_func_0x67.html", null ],
    [ "m", "globals_func_0x6d.html", null ],
    [ "s", "globals_func_0x73.html", null ],
    [ "u", "globals_func_0x75.html", null ]
];