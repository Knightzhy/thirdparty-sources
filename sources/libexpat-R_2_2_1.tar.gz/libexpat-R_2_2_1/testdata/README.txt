This directory contains various collections of files used for test
data.  It currently contains the following collections:

largefiles/
    This contains some really large files; most are used for
    benchmarking various aspects of Expat's performance.
